import processing.core.PApplet;


import java.awt.*;

//classe utile per i test iniziali del progetto per visualizzare le due pedane e la situazione iniziale del gioco
//con oggetti di tipo Rettangolo invece delle immagini create
public class showStart extends PApplet{
    private PApplet processing;
    private Rettangolo block1;
    private Rettangolo block2;

    public showStart(PApplet processing, Rettangolo block1, Rettangolo block2){
        this.processing = processing;
        this.block1 = block1;
        this.block2 = block2;
    }

    public void drawStart(Rettangolo blocco1, Rettangolo blocco2){
        blocco1.setX(0);
        blocco1.setY(300);
        blocco1.setWidth(100);
        blocco1.setHeight(200);
        blocco1.setBordo(new Color(0, 0, 0));
        blocco1.setColore(new Color(0, 0, 0));

        blocco2.setX(300);
        blocco2.setY(300);
        blocco2.setWidth(100);
        blocco2.setHeight(200);
        blocco2.setBordo(new Color(0, 0, 0));
        blocco2.setColore(new Color(0, 0, 0));

        blocco1.show();
        blocco2.show();
    }

}
