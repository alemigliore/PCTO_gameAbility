import processing.core.PApplet;

//classe utile per il punteggio e tutto ciò che lo riguarda
public class Score extends PApplet {
    private PApplet processing;
    private int score;

    public Score(PApplet processing) {
        this.processing = processing;
        this.score = 0;
    }

    //incremento del punteggio
    public void addScore(){
        this.score = this.score + 1;
    }

    //ritorno del punteggio
    public int getScore(){
        return this.score;
    }
}
