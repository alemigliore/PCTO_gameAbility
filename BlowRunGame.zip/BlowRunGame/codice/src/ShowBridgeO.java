import processing.core.PApplet;

//classe utile per i test iniziali del progetto, per visualizzare il ponte orizzontale come rettangolo e non con le immagini
public class ShowBridgeO {
    private PApplet processing;

    public ShowBridgeO(PApplet processing){
        this.processing = processing;
    }

    public void drawBridgeO(Rettangolo ponte){
        ponte.setX(90);
        ponte.setY(349);
        ponte.setWidth(Game.widthBridge);
        ponte.setHeight(1);
        ponte.show();
        Game.heightBridge = 0;
    }
}
