import processing.core.PApplet;
import processing.core.PImage;

//classe utile per la visualizzazione del ponte orizzontale
public class ShowBridgeImageO {
    private PApplet processing;
    //immagine del ponte
    private PImage bridge;

    public ShowBridgeImageO(PApplet processing, String bridge){
        this.processing = processing;
        this.bridge = processing.loadImage(bridge);
    }

    //visualizzazione del ponte orizzontale una volta costruito verticalmente
    public void drawBridgeImageO(){
        processing.image(bridge, 138, 350, Game.widthBridge, 5);
        Game.heightBridge = 0;
    }
}
