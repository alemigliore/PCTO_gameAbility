import processing.core.PApplet;
import processing.core.PImage;

//classe utile per la visualizzazione della schermata finale in caso di sconfitta
public class ShowGameOver extends PApplet{
    private PApplet processing;
    //2 frame per la visualizzazione della gif animata per la scritta "Game Over"
    private PImage frame1GO;
    private PImage frame2GO;
    //immagine della scritta "Score: "
    private PImage score;
    //immagine del numero che equivale al punteggio ottenuto
    private PImage number;
    private int frame;
    //variabili utili al posizionamento e dimensionamento della scritta "Game Over"
    private final int HEIGHT_GO = 192;
    private final int WIDTH_GO = 350;
    private final int X_GO = 225;
    private final int Y_GO = 50;
    //variabili utili al posizionamento e dimensionamento della scritta "Score: "
    private final int X_SCORE = 100;
    private final int Y_SCORE = 250;
    private final int WIDTH_SCORE = 600;
    private final int HEIGHT_SCORE = 180;
    //variabili utili al posizionamento e dimensionamento del numero
    private final int X_NUM = 525;
    private final int Y_NUM = 305;
    private final int WIDTH_NUM = 90;
    private final int HEIGHT_NUM = 70;

    public ShowGameOver(PApplet processing, String frame1, String frame2, String score) {
        this.processing = processing;
        this.frame1GO = processing.loadImage(frame1);
        this.frame2GO = processing.loadImage(frame2);
        this.score = processing.loadImage(score);
        this.number = processing.loadImage("numero_0.png");
    }

    //visualizzazione scritta game over e punteggio
    public void drawGameOver(int frameCount){
        this.frame = frameCount;
        if(frame % 50 < 26){
            processing.image(frame1GO, X_GO, Y_GO, WIDTH_GO, HEIGHT_GO);
        }else{
            processing.image(frame2GO, X_GO, Y_GO, WIDTH_GO, HEIGHT_GO);
        }
        processing.image(score, X_SCORE, Y_SCORE, WIDTH_SCORE, HEIGHT_SCORE);
        processing.image(this.number, 525, 305, 90, 70);
    }

    //impostazione e visualizzazione del punteggio
    public void setNumber(String number){
        this.number = processing.loadImage(number);
    }
}
