import processing.core.PApplet;
import processing.core.PImage;

//classe Rocket utile per la visualizzazione del razzo mobile in cielo
public class Rocket extends PApplet{
    private PApplet processing;
    //immagine del razzo
    private PImage rocket;
    int x = 0;

    public Rocket(PApplet processing, String rocket) {
        this.processing = processing;
        this.rocket = processing.loadImage(rocket);
    }

    //funzione che implementa la visualizzazione
    public void draw(){
        //processing.background(Game.background);
        processing.image(rocket, x, 100, 100, 47);
        x++;
        if(x == 800){
            x = 0;
        }
    }
}
