import processing.core.PApplet;
import processing.core.PImage;

//classe utile per la visualizzazione del ponte verticale
public class ShowBridgeImageV {
    private PApplet processing;
    //immagine del ponte
    private PImage bridge;

    public ShowBridgeImageV(PApplet processing, String bridge){
        this.processing = processing;
        this.bridge = processing.loadImage(bridge);
    }

    //visualizzazione ponte verticale mentre si costruisce
    public void drawBridgeImageV(){
        processing.image(bridge, 138, 350 - Game.widthBridge, 5, Game.widthBridge);
    }
}