import processing.core.PApplet;
import processing.core.PImage;
import processing.sound.Amplitude;
import processing.sound.AudioIn;
import processing.sound.*;

public class Game extends PApplet{
    //costanti che definiscono la grandezza dello schermo di gioco
    public static final int SCREEN_HEIGHT = 500;
    public static final int SCREEN_WIDTH = 800;

    //variabili utili per la costruzione e la visibilità delle piattaforme di gioco
    private PImage block1;
    private PImage block2;
    private ShowStartImage startImage;

    //variabili per il ponte, verticale quando si crea e orizzontale quando cade
    private ShowBridgeImageV bridgeImageV;
    private ShowBridgeImageO bridgeImageO;
    //variabile che definisce la lunghezza del ponte orizzontale
    public static int widthBridge = 0;
    //variabile che definisce l'altezza del ponte creato
    public static int heightBridge = 0;

    //razzo
    private Rocket rocket;
    //tasto play per iniziare a giocare
    private PImage buttonPlay;
    //tasto skin per cambiare il personaggio
    private PImage buttonSkin;
    //nome del gioco: Blow Run
    private PImage blowrun;
    //sfondo
    public static PImage background;
    //skin
    private ShowSkin skin;
    //game over, scritta visualizzata al momento della sconfitta
    private ShowGameOver gameOver;
    //punteggio, visualizzato al momento della sconfitta
    private Score score;
    String number;
    //variabile booleana che indica se si sta giocando o no
    private boolean isGameOn = false;
    //scritta: Wow, You're amazing, visualizzata se si arriva a un punteggio di 100
    private PImage amazing;
    //menù per cambiare il personaggio
    private SkinMenu menu;
    //variabile utile per visualizzare il menu delle skin
    private boolean isMenuOn = false;

    //variabili utili per il funzionamento della parte audio e di analisi di esso
    AudioIn input;
    Amplitude analyzer;
    float vol;

    public static void main(String[] args) {
        PApplet.main("Game");
    }

    //definizione dello schermo
    public void settings() {
        size(SCREEN_WIDTH, SCREEN_HEIGHT);
    }

    public void setup() {
        //impostazione dello sfondo
        background = loadImage("background.png");
        background.resize(SCREEN_WIDTH, SCREEN_HEIGHT);
        background(background);

        //dichiarazione e instanziazione degli oggetti
        score = new Score(this);

        buttonPlay = loadImage("buttonPlay.png");
        buttonSkin = loadImage("buttonSkin.png");
        blowrun = loadImage("gameName.png");

        skin = new ShowSkin(this,"corvo1.png", "corvo2.png");

        bridgeImageV = new ShowBridgeImageV(this, "bridgeV.png");

        bridgeImageO = new ShowBridgeImageO(this, "bridgeO.png");

        block1 = loadImage("pedana1.png");
        block2 = loadImage("pedana1.png");
        rocket = new Rocket(this, "razzo.png");
        startImage = new ShowStartImage(this);

        gameOver = new ShowGameOver(this, "gameOver.png", "gameOver2.png", "score.png");

        amazing = loadImage("amazing.png");

        menu = new SkinMenu(this, "box.png", "corvo1.png", "spike1.png", "leon1.png", "pekka1.png", "carl1.png", "mortis1.png");

        input = new AudioIn(this, 0);
        input.start();

        analyzer = new Amplitude(this);
        analyzer.input(input);
    }

    public void draw() {
        rocket.draw();
        //visualizzazione della schermata iniziale con nome del gioco, tasto play e tasto per cambiare skin
        if(score.getScore() == 0 && isGameOn == false && isMenuOn == false){
            background(background);
            image(blowrun, 100, 60, 600, 112);
            image(buttonPlay, 300, 210, 200, 80);
            image(buttonSkin, 360, 320, 80, 80);
            rocket.draw();
        }

        //se tasto skin viene premuto il menu per il cambio di personaggio viene visualizzato
        if(isMouseOver(360, 320, 80, 80) && mousePressed && isGameOn == false){
            isMenuOn = true;
            noLoop();
            delay(1000);
            loop();
        }

        //visualizzazione del menu personaggi e scelta
        if(isMenuOn == true){
            menu.drawMenu();
            if(isMouseOver(125, 75, 150, 150) && mousePressed){
                skin.setSkin("corvo1.png", "corvo2.png");
                isMenuOn = false;
            }
            if(isMouseOver(325, 75, 150, 150) && mousePressed){
                skin.setSkin("spike1.png", "spike2.png");
                isMenuOn = false;
            }
            if(isMouseOver(525, 75, 150, 150) && mousePressed){
                skin.setSkin("leon1.png", "leon2.png");
                isMenuOn = false;
            }
            if(isMouseOver(125, 275, 150, 150) && mousePressed){
                skin.setSkin("pekka1.png", "pekka2.png");
                isMenuOn = false;
            }
            if(isMouseOver(325, 275, 150, 150) && mousePressed){
                skin.setSkin("carl1.png", "carl2.png");
                isMenuOn = false;
            }
            if(isMouseOver(525, 275, 150, 150) && mousePressed){
                skin.setSkin("mortis1.png", "mortis2.png");
                isMenuOn = false;
            }
        }

        //se tasto play viene premuto il gioco inizia
        if(isMouseOver(300, 210, 200, 80) && mousePressed && isGameOn == false){
            isGameOn = true;
            noLoop();
            delay(1000);
            loop();
        }

        if(isGameOn == true && score.getScore() < 100){
            //visualizzazione parti del gioco
            background(background);
            rocket.draw();
            startImage.drawStartDefault(block1, block2);
            skin.drawSkin();
            //se in attesa di creare il nuovo ponte, ascoltare e analizzare l'audio
            if(skin.getX() == 98){
                vol = analyzer.analyze();
            }
            //se audio è compreso tra le seguenti soglie allora costruire il ponte
            if (vol >= 0.0285 && vol <= 0.07/*mousePressed && mouseButton == LEFT*/){
                heightBridge += 5;
                background(background);
                rocket.draw();
                startImage.drawStartDefault(block1, block2);
                skin.drawSkin();
                bridgeImageV.drawBridgeImageV();
                widthBridge = heightBridge;
            }else{
                //se ponte è di dimensioni corrette, disegnare il ponte orizzontale, far avanzare il personaggio e incrementare punteggio
                if((138 + widthBridge) < (ShowStartImage.x + 150) && (138 + widthBridge) > ShowStartImage.x){
                    background(background);
                    rocket.draw();
                    startImage.drawStartDefault(block1, block2);
                    bridgeImageO.drawBridgeImageO();
                    skin.goSkinRight();
                    if(ShowStartImage.x + skin.getXDefault() == skin.getX()){
                        widthBridge = 0;
                        background(background);
                        rocket.draw();
                        startImage.setX();
                        startImage.drawStartDefault(block1, block2);
                        skin.drawSkin();
                        skin.setX();
                        score.addScore();
                    }
                }else{
                    //altrimenti far avanzare il personaggio fino al momento della sua caduta e visualizzare la schermata game over con il punteggio
                    if(widthBridge != 0){
                        background(background);
                        rocket.draw();
                        startImage.drawStartDefault(block1, block2);
                        bridgeImageO.drawBridgeImageO();
                        if(skin.getX() < 138 + widthBridge){
                            skin.goSkinFail();
                        }else{
                            number = "numero_" + this.score.getScore() + ".png";
                            gameOver.setNumber(number);
                            gameOver.drawGameOver(frameCount);
                            skin.fallSkin();
                            if(skin.getY() >= SCREEN_HEIGHT){
                                delay(5000);
                                exit();
                            }
                        }
                    }
                }
            }
        }

        //se il punteggio è superiore a 99, concludere il gioco mostrando la scritta: "WOW, you're amazing"
        if(score.getScore() > 99){
            isGameOn = false;
            background(background);
            image(amazing, 100, 116,600, 268);
        }
    }

    //funzione utile a capire se il mouse si trova in una determinata area
    public boolean isMouseOver(int x, int y, int w, int h){
        if(mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h){
            return  true;
        }
        return false;
    }
}
