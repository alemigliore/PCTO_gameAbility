import processing.core.PApplet;
import processing.core.PImage;

//classe utile per visualizzare la situazione iniziale di ogni "livello": le due pedane
public class ShowStartImage extends PApplet{
    private PApplet processing;
    public static int x;

    //costruttore che instanzia la classe e imposta una posizione casuale compresa tra 300 e 500 per la seconda pedana
    public ShowStartImage(PApplet processing){
        this.processing = processing;
        x = (int) random(300, 500);
    }

    //visualizzazione scenario
    public void drawStartDefault(PImage block1, PImage block2){
        processing.image(block2, x, 350, 150, 70);
        processing.image(block1, 0, 350, 150, 70);
    }

    //imposta una posizione casuale compresa tra 300 e 500 per la seconda pedana
    public void setX(){
        x = (int) random(300, 600);
    }
}