import processing.core.PApplet;
import processing.core.PImage;

//classe che permette l'inizializzazione e la visualizzazione del menu per cambiare il personaggio
public class SkinMenu extends  PApplet{
    private PApplet processing;
    //immagini di ogni personaggio disponibile utili per la visualizzazione del menù
    private PImage box;
    private PImage crow;
    private PImage spike;
    private PImage leon;
    private PImage pekka;
    private PImage carl;
    private PImage mortis;

    public SkinMenu(PApplet processing, String box, String crow, String spike, String leon, String pekka, String carl, String mortis){
        this.processing = processing;
        this.box = processing.loadImage(box);
        this.crow = processing.loadImage(crow);
        this.spike = processing.loadImage(spike);
        this.leon = processing.loadImage(leon);
        this.pekka = processing.loadImage(pekka);
        this.carl = processing.loadImage(carl);
        this.mortis = processing.loadImage(mortis);
    }

    //funzione che implementa la visualizzazione del menu
    public void drawMenu(){
        processing.background(Game.background);
        //visualizzazione del riquadro che contiene l'immagine di ogni personaggio
        processing.image(this.box, 125, 75, 150, 150);
        processing.image(this.box, 325, 75, 150, 150);
        processing.image(this.box, 525, 75, 150, 150);
        processing.image(this.box, 125, 275, 150, 150);
        processing.image(this.box, 325, 275, 150, 150);
        processing.image(this.box, 525, 275, 150, 150);
        //visualizzazione di ogni skin all'interno del proprio riquadro
        processing.image(this.crow, 166, 85, 68, 130);
        processing.image(this.spike, 335, 85, 130, 130);
        processing.image(this.leon, 566, 85, 68, 130);
        processing.image(this.pekka, 166, 285, 85, 130);
        processing.image(this.carl, 366, 285, 68, 130);
        processing.image(this.mortis, 566, 285, 85, 130);
    }

}
