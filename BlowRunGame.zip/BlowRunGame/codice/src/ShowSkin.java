import processing.core.PApplet;
import processing.core.PImage;

//classe ShowSkin utile per tutto ciò che riguarda il personaggio e i suoi movimenti
public class ShowSkin extends PApplet{
    private PApplet processing;
    //2 frame utili alla visualizzazione della gif animata della skin
    private PImage frame1;
    private PImage frame2;
    //variabili utili al posizionamento e dimensionamento della skin
    private final int xDefault = 98;
    private final int yDefault = 272;
    private final int widthSkin = 40;
    private final int heightSkin = 78;
    //variabili che indicano la posizione della skin in qualsiasi momento
    private int x;
    private int y;

    public ShowSkin(PApplet processing, String frame1, String frame2) {
        this.processing = processing;
        this.frame1 = processing.loadImage(frame1);
        this.frame2 = processing.loadImage(frame2);
        this.x = xDefault;
        this.y = yDefault;
    }

    //visualizzazione skin ferma alla partenza
    public void drawSkin(){
        processing.image(frame1, xDefault, yDefault, widthSkin, heightSkin);
    }

    //camminata del personaggio se il ponte è troppo corto o troppo lungo
    public void goSkinFail(){
        if(this.x <= Game.SCREEN_WIDTH){
            if(x % 8 < 5){
                processing.image(frame1, x, yDefault, widthSkin, heightSkin);
            }else{
                processing.image(frame2, x, yDefault, widthSkin, heightSkin);
            }
            x++;
        }
    }

    //camminata del personaggio se il ponte è delle dimensioni corrette
    public void goSkinRight(){
        if(x % 8 < 5){
            processing.image(frame1, x, yDefault, widthSkin, heightSkin);
        }else{
            processing.image(frame2, x, yDefault, widthSkin, heightSkin);
        }
        if(this.x <= ShowStartImage.x + xDefault){
            x++;
        }

    }

    //caduta verso il basso della skin in caso di sconfitta
    public void fallSkin(){
        if(this.y <= Game.SCREEN_HEIGHT){
            processing.image(frame1, x, y, widthSkin, heightSkin);
            y += 4;
        }
    }

    //restituisce la posizione x della skin
    public int getX(){
        return this.x;
    }

    //restituisce la posizione y della skin
    public int getY(){
        return this.y;
    }

    //restituisce la posizione xDefault della skin, quella in posizione di partenza
    public int getXDefault() {
        return this.xDefault;
    }

    //imposta la x della skin a quella di partenza
    public void setX(){
        this.x = xDefault;
    }

    //seleziona la skin scelta
    public void setSkin(String frame1, String frame2){
        this.frame1 = processing.loadImage(frame1);
        this.frame2 = processing.loadImage(frame2);
    }
}
