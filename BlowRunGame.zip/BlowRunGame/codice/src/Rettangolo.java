import processing.core.PApplet;
import java.awt.*;

//classe Rettangolo, utile per i test iniziali del progetto
public class Rettangolo {
    private float x;
    private float y;
    private float height;
    private float width;
    private final float  X_DEFAULT = 100;
    private final float  Y_DEFAULT = 50;
    private final float  HEIGHT_DEFAULT = 200;
    private final float  WIDTH_DEFAULT = 100;
    private Color colore;
    private Color bordo;

    private PApplet processing;

    public Rettangolo(PApplet processing){
        this.processing = processing;
        x = X_DEFAULT;
        y = Y_DEFAULT;
        height = HEIGHT_DEFAULT;
        width = WIDTH_DEFAULT;
        colore = new Color(255, 27, 0);
        bordo = new Color (0, 0, 0);
    }

    public Rettangolo() {

    }

    public void show(){
        processing.stroke(bordo.getRGB()); //colore bordo
        processing.fill(colore.getRGB()); //colore di riempimento
        processing.rect(x, y, width, height);
    }

    public void setX(float x){
        this.x = x;
    }
    public void setY(float y){
        this.y = y;
    }
    public void setHeight(float height){
        this.height = height;
    }
    public void setWidth(float width){
        this.width = width;
    }

    public float getX() {
        return x;
    }
    public float getY() {
        return y;
    }
    public float getHeight() {
        return height;
    }
    public float getWidth() {
        return width;
    }

    public void setColore(Color colore){
        this.colore = colore; //new color()
    }
    public Color getColore(){
        return colore;
    }

    public Color getBordo(){
        return bordo;
    }
    public void setBordo(Color colore){
        bordo = colore;
    }
}
