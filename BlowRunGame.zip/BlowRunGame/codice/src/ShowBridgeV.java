import processing.core.PApplet;

//classe utile per i test iniziali del progetto, per visualizzare il ponte verticale come rettangolo e non con le immagini
public class ShowBridgeV {
    private PApplet processing;

    public ShowBridgeV(PApplet processing){
        this.processing = processing;
    }

    public void drawBridgeV(Rettangolo ponte){
        ponte.setX(99);
        ponte.setY(350 - Game.heightBridge);
        ponte.setWidth(1);
        ponte.setHeight(Game.heightBridge);
        ponte.show();
    }
}
