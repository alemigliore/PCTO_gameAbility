package processing.sound;
import com.jsyn.ports.UnitOutputPort;
import processing.core.PApplet;

class FFT extends Analyzer {

    public float[] spectrum;

    private JSynFFT fft;

    public FFT(PApplet parent) {
        this(parent, 512);
    }

    public FFT(PApplet parent, int bands) {
        super(parent);
        if (bands < 0 || Integer.bitCount(bands) != 1) {
            // TODO throw RuntimeException?
            Engine.printError("number of FFT bands needs to be a power of 2");
        } else {
            // FFT buffer size is twice the number of frequency bands
            this.fft = new JSynFFT(2 * bands);
            this.spectrum = new float[bands];
        }
    }

    protected void removeInput() {
        this.fft.input.disconnectAll();
        this.input = null;
    }

    protected void setInput(UnitOutputPort input) {
        // superclass makes sure that input unit is actually playing, just connect it
        Engine.getEngine().add(this.fft);
        this.fft.input.connect(input);
        this.fft.start();
    }

    public float[] analyze() {
        return this.analyze(this.spectrum);
    }

    public float[] analyze(float[] value) {
        if (this.input == null) {
            Engine.printWarning("this FFT has no sound source connected to it, nothing to analyze");
        }
        this.fft.calculateMagnitudes(value);
        return value;
    }

    public void input(SoundObject input) {
        super.input(input);
    }
}